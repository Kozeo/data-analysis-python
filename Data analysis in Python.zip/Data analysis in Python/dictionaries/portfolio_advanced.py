# pylint: disable=missing-docstring

# TODO: start by defining a `portfolio` using a dict!

import requests

url = "https://api.iextrading.com/1.0/tops/last?symbols=AAPL,GOOG,TSLA,FB"
real_time_market = requests.get(url).json()

portfolio = {
  "AAPL": {
    "volume": 10,
    "strike": 154.12,
    "market": real_time_market[0]['price']
  },
  "GOOG": {
    "volume": 2,
    "strike": 812.56,
    "market": real_time_market[1]['price']
  },
  "TSLA": {
    "volume": 12,
    "strike": 342.12,
    "market": real_time_market[2]['price']
  },
  "FB": {
    "volume": 18,
    "strike": 209.0,
    "market": real_time_market[3]['price']
  }
}

print(portfolio["AAPL"]["volume"])
print(portfolio["GOOG"]["strike"])

market = {
    "aapl-market": 198.84,
    "goog-market": 1217.93,
    "tsl-market": 267.66,
    "fb-market": 179.06
}

pnl_value = 0;

for p_id, p_info in portfolio.items():
        pnl_value = pnl_value + p_info["volume"] * (p_info["market"] - p_info["strike"])
        
print(pnl_value)
        