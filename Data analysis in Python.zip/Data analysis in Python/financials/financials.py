# pylint: disable=missing-docstring

# TODO: 1st exercise: Define the `forward_price` function
# TODO: 2nd exercise: Define the `short_pnl` function

import math

def forward_price(spot, interest_rate, time):
    x_exp = interest_rate * time
    fwp = round(spot * math.exp(x_exp), 2)
    return fwp

def short_pnl(positions, mtm):
    pnl_value = 0
    for i in range(0, 3):
        pnl_value = pnl_value + positions[i] - mtm[i]
    return pnl_value
