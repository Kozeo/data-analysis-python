# pylint: disable=missing-docstring,invalid-name

def summify(x, y):
    return x+y

def multiply(x, y):
    return x*y
